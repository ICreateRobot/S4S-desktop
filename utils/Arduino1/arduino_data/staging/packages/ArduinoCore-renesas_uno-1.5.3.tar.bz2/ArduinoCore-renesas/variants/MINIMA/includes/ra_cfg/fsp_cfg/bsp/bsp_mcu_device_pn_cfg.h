/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7FA4M1AB3CNE
#define BSP_MCU_FEATURE_SET ('A')
#define BSP_ROM_SIZE_BYTES (262144)
#define BSP_RAM_SIZE_BYTES (32768)
#define BSP_DATA_FLASH_SIZE_BYTES (8192)
#define BSP_PACKAGE_QFN
#define BSP_PACKAGE_PINS (48)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
